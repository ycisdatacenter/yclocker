(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a257ef5a._.js",
  "static/chunks/app_dashboard_page_tsx_ad9a6368._.js"
],
    source: "dynamic"
});
