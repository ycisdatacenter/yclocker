(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6a439fac._.js",
  "static/chunks/app_login_page_tsx_ed82f28e._.js"
],
    source: "dynamic"
});
