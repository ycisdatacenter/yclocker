(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a257ef5a._.js",
  "static/chunks/app_admin_dashboard_page_tsx_08a05697._.js"
],
    source: "dynamic"
});
