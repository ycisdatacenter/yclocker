(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6a439fac._.js",
  "static/chunks/app_admin_page_tsx_9b891d59._.js"
],
    source: "dynamic"
});
