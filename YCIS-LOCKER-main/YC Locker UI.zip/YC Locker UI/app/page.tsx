'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { 
  ShieldCheckIcon, 
  CloudArrowUpIcon, 
  DocumentTextIcon,
  AcademicCapIcon,
  LockClosedIcon,
  DevicePhoneMobileIcon
} from '@heroicons/react/24/outline'

const features = [
  {
    title: 'Secure Storage',
    description: 'Store your documents securely with enterprise-grade encryption and protection.',
    icon: ShieldCheckIcon,
    bgColor: 'bg-blue-50',
    textColor: 'text-blue-600'
  },
  {
    title: 'Easy Access',
    description: 'Access your documents anytime, anywhere with our user-friendly interface.',
    icon: CloudArrowUpIcon,
    bgColor: 'bg-indigo-50',
    textColor: 'text-indigo-600'
  },
  {
    title: 'File Management',
    description: 'Organize, search, and manage your documents efficiently.',
    icon: DocumentTextIcon,
    bgColor: 'bg-purple-50',
    textColor: 'text-purple-600'
  },
  {
    title: 'Student Focused',
    description: 'Designed specifically for students to manage their academic documents.',
    icon: AcademicCapIcon,
    bgColor: 'bg-pink-50',
    textColor: 'text-pink-600'
  },
  {
    title: 'Privacy First',
    description: 'Your data privacy is our top priority with secure authentication.',
    icon: LockClosedIcon,
    bgColor: 'bg-green-50',
    textColor: 'text-green-600'
  },
  {
    title: 'Mobile Ready',
    description: 'Access your documents on any device with our responsive design.',
    icon: DevicePhoneMobileIcon,
    bgColor: 'bg-orange-50',
    textColor: 'text-orange-600'
  }
]

export default function Home() {
  const [heroRef, heroInView] = useInView({ triggerOnce: true })
  const [featuresRef, featuresInView] = useInView({ triggerOnce: true, threshold: 0.1 })
  const [ctaRef, ctaInView] = useInView({ triggerOnce: true })

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <header className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 mix-blend-multiply" />
          <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        </div>
        <nav className="relative container mx-auto px-6 py-6 flex justify-between items-center">
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold tracking-tight"
          >
            YCIS College
          </motion.h1>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link 
              href="/login" 
              className="group px-6 py-3 bg-white/10 hover:bg-white/20 rounded-full transition-all duration-300 font-medium backdrop-blur-sm inline-flex items-center space-x-2"
            >
              <span>Student Login</span>
              <svg className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </motion.div>
        </nav>
      </header>

      <main>
        <section ref={heroRef} className="relative py-20 sm:py-24 lg:py-32 overflow-hidden">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={heroInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="container mx-auto px-6 text-center max-w-[1200px]"
          >
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-8 bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-transparent bg-clip-text leading-tight">
              Welcome to YCIS College<br />
              <span className="text-3xl sm:text-4xl lg:text-5xl bg-gradient-to-r from-blue-500 to-blue-700 text-transparent bg-clip-text">
                Storage System
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed mb-12">
              A secure platform for students to store and manage their important documents with ease and confidence.
            </p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={heroInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <Link 
                href="/register" 
                className="inline-flex items-center px-8 py-4 text-lg font-medium text-white bg-gradient-to-r from-blue-600 to-blue-700 rounded-full hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-0.5 group"
              >
                Get Started
                <svg className="w-5 h-5 ml-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </Link>
            </motion.div>
          </motion.div>
        </section>

        <section ref={featuresRef} className="py-20 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={featuresInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Everything You Need
              </h2>
              <p className="text-xl text-gray-600">
                Powerful features to help you manage your documents
              </p>
            </motion.div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={featuresInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.7, delay: index * 0.1 }}
                  className="bg-white p-8 rounded-2xl shadow-[0_20px_50px_rgba(8,_112,_184,_0.07)] hover:shadow-[0_20px_50px_rgba(8,_112,_184,_0.13)] transition-all duration-300 group hover:-translate-y-1"
                >
                  <div className={`${feature.bgColor} w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <feature.icon className={`w-7 h-7 ${feature.textColor}`} />
                  </div>
                  <h3 className="text-xl font-semibold mb-4 text-gray-900">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section ref={ctaRef} className="py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={ctaInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="container mx-auto px-6"
          >
            <div className="relative rounded-3xl overflow-hidden">
              <div className="absolute inset-0">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 mix-blend-multiply" />
                <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
              </div>
              <div className="relative text-center py-16 px-6">
                <h2 className="text-3xl font-bold text-white mb-8">
                  Ready to Get Started?
                </h2>
                <Link 
                  href="/register" 
                  className="inline-flex items-center px-8 py-4 text-lg font-medium text-blue-600 bg-white rounded-full hover:bg-gray-50 transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-0.5 group"
                >
                  Create Your Account
                  <svg className="w-5 h-5 ml-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </Link>
              </div>
            </div>
          </motion.div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white mt-auto">
        <div className="container mx-auto px-6 py-12">
          <div className="text-center">
            <p className="text-gray-400">&copy; {new Date().getFullYear()} YCIS College. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
