(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6a439fac._.js",
  "static/chunks/app_register_page_tsx_e7797bdb._.js"
],
    source: "dynamic"
});
